import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { InfrastructureModule } from './infrastructure/infrastructure.module';
import { AccessTokenModule } from './presentation/http/access-token.module';
import { AuthModule } from './presentation/http/auth.module';
import { HomeModule } from './presentation/http/home.module';
import { ProfileModule } from './presentation/http/profile.module';
import { RankingsModule } from './presentation/http/rankings.module';
import { SecurityAuditMiddleware } from './presentation/http/security-audit';
import { SessionsModule } from './presentation/http/sessions.module';
import { StatisticsModule } from './presentation/http/statistics.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    InfrastructureModule,
    AccessTokenModule,
    AuthModule,
    HomeModule,
    ProfileModule,
    SessionsModule,
    RankingsModule,
    StatisticsModule,
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(SecurityAuditMiddleware).forRoutes('*path');
  }
}
